/*
 * getdirentry
 */

#include "test.h"

void
test_getdirentry(void)
{
	test_getdirentry_fd();
	test_getdirentry_buf();
}
