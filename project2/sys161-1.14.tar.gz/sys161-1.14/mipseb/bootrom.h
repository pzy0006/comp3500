int bootrom_fetch(u_int32_t offset, u_int32_t *val);
const u_int32_t *bootrom_map(u_int32_t offset);
